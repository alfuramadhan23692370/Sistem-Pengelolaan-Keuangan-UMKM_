from sklearn.linear_model import LinearRegression
import numpy as np

# contoh data sederhana
X = np.array([[1], [2], [3], [4], [5]])
y = np.array([100, 200, 300, 400, 500])

model = LinearRegression()
model.fit(X, y)

def predict_profit(x):
    return model.predict([[x]])[0]