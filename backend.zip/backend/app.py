from flask import Flask, jsonify, request

app = Flask(__name__)

# =========================
# ROUTE UTAMA
# =========================
@app.route("/")
def home():
    return "Backend Sistem Pengelolaan Keuangan UMKM Aktif 🚀"

# =========================
# TEST API
# =========================
@app.route("/test", methods=["GET"])
def test():
    return jsonify({
        "status": "success",
        "message": "API Flask berjalan dengan baik"
    })

# =========================
# CONTOH API TRANSAKSI
# =========================
transactions = []

@app.route("/transaksi", methods=["GET", "POST"])
def transaksi():
    if request.method == "POST":
        data = request.json

        transaksi_baru = {
            "id": len(transactions) + 1,
            "nama": data.get("nama"),
            "jumlah": data.get("jumlah"),
            "tipe": data.get("tipe")  # pemasukan / pengeluaran
        }

        transactions.append(transaksi_baru)

        return jsonify({
            "message": "Transaksi berhasil ditambahkan",
            "data": transaksi_baru
        })

    return jsonify(transactions)

# =========================
# RUN SERVER
# =========================
if __name__ == "__main__":
    print("URL Routes:", app.url_map)
    app.run(debug=True)
    
    from model import predict_profit

@app.route("/predict", methods=["POST"])
def predict():
    data = request.json
    nilai = data["nilai"]

    hasil = predict_profit(nilai)

    return jsonify({
        "input": nilai,
        "prediksi_profit": hasil
    })