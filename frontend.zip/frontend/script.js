const API = "http://127.0.0.1:5000/transaksi";

async function kirimData() {
    const data = {
        nama: document.getElementById("nama").value,
        jumlah: document.getElementById("jumlah").value,
        tipe: document.getElementById("tipe").value
    };

    await fetch(API, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    });

    loadData();
}

async function loadData() {
    const res = await fetch(API);
    const data = await res.json();

    const list = document.getElementById("list");
    list.innerHTML = "";

    data.forEach(item => {
        list.innerHTML += `
            <li>${item.nama} - ${item.jumlah} (${item.tipe})</li>
        `;
    });
}

loadData();